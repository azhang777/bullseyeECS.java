package com.example.bulleyefx;

public class Administrator extends User {
    private String userId, password, email;
    private boolean is_logged_in;

    /*
    addPromotionalDiscount()
     */
}
