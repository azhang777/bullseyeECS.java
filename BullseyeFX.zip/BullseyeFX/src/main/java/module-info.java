module com.example.bullseyefx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.bullseyefx to javafx.fxml;
    exports com.example.bullseyefx;
}