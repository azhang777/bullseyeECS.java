package com.example.bullseyefx;

import java.util.ArrayList;
import java.util.List;

public class Cart {
    private String date_created;
    private Product product;
    private  int quantityAdded;
    private int totalItems;
    private int cardId;
    static List<Product> cartList = new ArrayList<>();

    public String getDate_created() {
        return date_created;
    }

    public void setDate_created(String date_created) {
        this.date_created = date_created;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getQuantityAdded() {
        return quantityAdded;
    }

    public void setQuantityAdded(int quantityAdded) {
        this.quantityAdded = quantityAdded;
    }

    public int getTotalItems() {
        return totalItems;
    }

    public void setTotalItems(int totalItems) {
        this.totalItems = totalItems;
    }

    public int getCardId() {
        return cardId;
    }

    public void setCardId(int cardId) {
        this.cardId = cardId;
    }

    public static List<Product> getCartList() {
        return cartList;
    }
//
//   public static void setCartList(List<Product> cartList) {
//        Cart.cartList = cartList;
//   }

    public void addCartItem(Product product) {
        cartList.add(product);
    }
    public void addTotalItems() {
        float total = 0;
        for (Product products: cartList) {
            total += products.getPrice();
        }
    }
}