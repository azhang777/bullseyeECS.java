package com.example.bulleyefx;

public class Inventory {
    /*
    addStock()
    removeStock()
     */
}
