package com.example.bulleyefx;

public class Product extends Inventory {
    private String name, gender, size, itemColor;
    private int quantityAmount, idNumber;
    private float price;

}
