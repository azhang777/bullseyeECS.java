import java.util.Objects;

public class Book {
    //numberID,title_book,title_series_book,author_name,has_series,series_number,avg_rating,total_rating,voters,score
    String title_book,title_series, author_name;
    boolean has_series;
    int numberID, series_number, total_rating, voters, score;
    float avg_rating;

    public Book() {

    }
    public String getTitle_book() {
        return title_book;
    }

    public void setTitle_book(String title_book) {
        this.title_book = title_book;
    }

    public String getTitle_series() {
        return title_series;
    }

    public void setTitle_series(String title_series) {
        this.title_series = title_series;
    }

    public String getAuthor_name() {
        return author_name;
    }

    public void setAuthor_name(String author_name) {
        this.author_name = author_name;
    }

    public boolean isHas_series() {
        return has_series;
    }

    public void setHas_series(boolean has_series) {
        this.has_series = has_series;
    }

    public int getNumberID() {
        return numberID;
    }

    public void setNumberID(int numberID) {
        this.numberID = numberID;
    }

    public int getSeries_number() {
        return series_number;
    }

    public void setSeries_number(int series_number) {
        this.series_number = series_number;
    }

    public int getTotal_rating() {
        return total_rating;
    }

    public void setTotal_rating(int total_rating) {
        this.total_rating = total_rating;
    }

    public int getVoters() {
        return voters;
    }

    public void setVoters(int voters) {
        this.voters = voters;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public float getAvg_rating() {
        return avg_rating;
    }

    public void setAvg_rating(float avg_rating) {
        this.avg_rating = avg_rating;
    }

    //numberID,title_book,title_series_book,author_name,has_series,series_number,avg_rating,total_rating,voters,score
    @Override
    public String toString() {
        return "\nBook[" + "Number ID: " + numberID + ", Title Name: " + title_book + ", has Series: " + has_series +
                ", Title Series: " + title_series + ", Series Number: " + series_number + ", Author Name: " + author_name +
                ", Total Rating: " + total_rating + ", Voters: " + voters +
                ", Score: " + score + ", Average Rating: " + avg_rating + "]\n";
    }
}
