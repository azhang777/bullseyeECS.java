package com.example.bullseyefx;

public class Administrator extends User {
    private String userId;
    private String password;
    private String email;
    private boolean is_logged_in;

    public Administrator() {

    }

}
