package com.example.bulleyefx;

public class Order {
    private String orderID, orderDate, orderDescription;
    private int orderItems;
    private float totalPrice;

    /*
    order_create(orderID, orderDate, orderItems, totalPrice, orderDescription)
     */
}
