package com.example.bullseyefx;

public class Cart {
    private String date_created;
    private Product product;
    private int quantity;
    private int totalItems;
    private int itemId;
    private int cardId;

    public void addCartItem() {

    }

    public void deleteCartItem() {

    }

    public void viewCartItem() {

    }

    public void checkout() {

    }
}