package com.example.bullseyefx;

public class Product extends Inventory {
    private String name;
    private String gender;
    private String size;
    private String itemColor;
    private int quantityAmount;
    private int idNumber;
    private float price;

    public Product() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getItemColor() {
        return itemColor;
    }

    public void setItemColor(String itemColor) {
        this.itemColor = itemColor;
    }

    public int getQuantityAmount() {
        return quantityAmount;
    }

    public void setQuantityAmount(int quantityAmount) {
        this.quantityAmount = quantityAmount;
    }

    public int getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(int idNumber) {
        this.idNumber = idNumber;
    }

    public float getPrice() {
        return price;
    }
    public void setPrice(float price) {
        this.price = price;
    }

    public void increaseQuantity() {
        this.quantityAmount++;
    }

    public void decreaseQuantity() {
        if (this.quantityAmount > 0) {
            this.quantityAmount--;
        }
    }

    @Override
    public String toString() {
        return "name:'" + name + '\'' + ", gender:'" + gender + '\'' + ", size:'" + size + '\'' + ", itemColor:'" + itemColor + '\'' + ", quantityAmount:" + quantityAmount + ", idNumber:" + idNumber + ", price:" + price;
    }
}
