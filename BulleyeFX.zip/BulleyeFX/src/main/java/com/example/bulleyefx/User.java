package com.example.bulleyefx;

public class User {
    private String userId, password;
    private boolean is_logged_in;

    /*
    verfyLogin();

     */
}
