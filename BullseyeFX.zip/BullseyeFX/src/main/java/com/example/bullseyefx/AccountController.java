package com.example.bullseyefx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class AccountController {

    @FXML
    private ListView<String> accountDetailList;
    List<Customer> customerList = new ArrayList<>();
    int i;
    BufferedReader bufferedReader = null;
    File loggedUser = new File("C:\\Users\\andyz\\IdeaProjects\\BullseyeFX\\src\\main\\java\\com\\example\\bullseyefx\\loggedUser.txt");
    File orderHistory = new File("C:\\Users\\andyz\\IdeaProjects\\BullseyeFX\\src\\main\\java\\com\\example\\bullseyefx\\orderHistory.txt");
    @FXML
    private Button cartBttn;

    @FXML
    private Button homeBttn;

    @FXML
    private ListView<String> orderDetailList;
    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField usernameField;

    @FXML
    private Button signInBttn;

    @FXML
    private Button signUpBttn;
    @FXML
    private Button logOutBttn;

    @FXML
    private Button refreshBttn;
    User user = new User();
    private Stage stage;
    private Scene scene;

    public AccountController() throws IOException {
    }


    @FXML
    void refreshBttnClicked(ActionEvent event) {
        Customer loggedCustomer = new Customer();
        try {
            FileReader file = new FileReader(loggedUser);
            bufferedReader = new BufferedReader(file);
            String line = "";

            while ((line = bufferedReader.readLine()) != null) {
                String[] data = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
                loggedCustomer.setUserID(data[0]);
                loggedCustomer.setPassword(data[1]);
                loggedCustomer.setFirstName(data[2]);
                loggedCustomer.setLastName(data[3]);
                loggedCustomer.setAddress(data[4]);
                loggedCustomer.setZipCode(data[5]);
                loggedCustomer.setEmail(data[6]);
                loggedCustomer.setPhoneNum(data[7]);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
            if (user.getIs_logged_in()) {
                accountDetailList.getItems().clear();
                orderDetailList.getItems().clear();
                accountDetailList.getItems().add("Username: " + loggedCustomer.getUserID());
                accountDetailList.getItems().add("Password: " + loggedCustomer.getPassword());
                accountDetailList.getItems().add("First Name: " + loggedCustomer.getFirstName());
                accountDetailList.getItems().add("Last Name: " + loggedCustomer.getLastName());
                accountDetailList.getItems().add("Address: " + loggedCustomer.getAddress());
                accountDetailList.getItems().add("ZipCode: " + loggedCustomer.getZipCode());
                accountDetailList.getItems().add("Email: " + loggedCustomer.getEmail());
                accountDetailList.getItems().add("Phone Number: " + loggedCustomer.getPhoneNum());
                signInBttn.setText("Sign In");
            }
        try {
            FileReader reader = new FileReader(orderHistory);
            BufferedReader br = new BufferedReader(reader);
            String line = "";
            while ((line = br.readLine()) != null) {
                orderDetailList.getItems().add(line);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    @FXML
    void switchToHome(ActionEvent event) throws IOException {
        System.out.println("Switch to Home Clicked");
        Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("hello-view.fxml"));
        this.stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(this.scene);
        this.stage.show();
    }

    public void switchToCart(ActionEvent event) throws IOException {
        System.out.println("Switch to Cart Clicked");
        Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("cart-view.fxml"));
        this.stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(this.scene);
        this.stage.show();
    }

    public void switchToSignUp(ActionEvent event) throws IOException {
        System.out.println("Switch to SignUp Clicked");
        Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("create-view.fxml"));
        this.stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(this.scene);
        this.stage.show();
    }

    public void logIn(ActionEvent actionEvent) {
        System.out.println("Log In Button Clicked");
        try {
            FileReader dataFile = new FileReader("C:\\Users\\andyz\\IdeaProjects\\BullseyeFX\\src\\main\\java\\com\\example\\bullseyefx\\UserInfo.csv");
            bufferedReader = new BufferedReader(dataFile);

            String line = "";
            bufferedReader.readLine();

            while ((line = bufferedReader.readLine()) != null) {
                String[] data = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
                Customer customer = new Customer();
                customer.setUserID(data[0]);
                customer.setPassword(data[1]);
                customer.setFirstName(data[2]);
                customer.setLastName(data[3]);
                customer.setAddress(data[4]);
                customer.setZipCode(data[5]);
                customer.setEmail(data[6]);
                customer.setPhoneNum(data[7]);
                customerList.add(customer);
            }

            for (Customer each: customerList){
                if (usernameField.getText().equals(customerList.get(i).getUserID()) && passwordField.getText().equals(customerList.get(i).getPassword())) {
                     user.setIs_logged_in(true);
                    break;
                }
                else {
                    i++;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
            if (user.getIs_logged_in()) {
                //we created the account list, still need the order list. ******
                accountDetailList.getItems().clear();
                orderDetailList.getItems().clear();
                accountDetailList.getItems().add("Username: " + customerList.get(i).getUserID());
                accountDetailList.getItems().add("Password: " + customerList.get(i).getPassword());
                accountDetailList.getItems().add("First Name: " + customerList.get(i).getFirstName());
                accountDetailList.getItems().add("Last Name: " + customerList.get(i).getLastName());
                accountDetailList.getItems().add("Address: " + customerList.get(i).getAddress());
                accountDetailList.getItems().add("ZipCode: " + customerList.get(i).getZipCode());
                accountDetailList.getItems().add("Email: " + customerList.get(i).getEmail());
                accountDetailList.getItems().add("Phone Number: " + customerList.get(i).getPhoneNum());
                signInBttn.setText("Sign In");

                try {
                    FileReader reader = new FileReader(orderHistory);
                    BufferedReader br = new BufferedReader(reader);
                    String line = "";
                    while ((line = br.readLine()) != null) {
                        orderDetailList.getItems().add(line);
                    }
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
                try {
                    FileWriter writer = new FileWriter(loggedUser);
                    writer.write(customerList.get(i).getUserID() + "," + customerList.get(i).getPassword() + "," + customerList.get(i).getFirstName() + "," + customerList.get(i).getLastName() + "," + customerList.get(i).getAddress() + "," + customerList.get(i).getZipCode() + "," + customerList.get(i).getEmail() + "," + customerList.get(i).getPhoneNum());
                    writer.close();
                } catch (IOException e) {
                    System.out.println("An error occurred.");
                    e.printStackTrace();
                }
            }
            else {
                signInBttn.setText("Error");
            }
        }
    @FXML
    void logOutBttnClicked(ActionEvent event) {
        user.setIs_logged_in(false);
        accountDetailList.getItems().clear();
        orderDetailList.getItems().clear();
    }
}
