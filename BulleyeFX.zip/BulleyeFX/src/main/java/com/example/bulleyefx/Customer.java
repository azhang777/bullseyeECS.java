package com.example.bulleyefx;

public class Customer extends User {
    private String phoneNum, address, zipCode, email, userID, password;
    private boolean is_logged_in;

    /*
    login()
     */
}
