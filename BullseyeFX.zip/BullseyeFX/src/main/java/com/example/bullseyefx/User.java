
package com.example.bullseyefx;

public class User {
    private String userId;
    private String password;
    private boolean is_logged_in;

    public User() {
    }

    public void authenticate() {

    }

    public void create() {

    }
}
