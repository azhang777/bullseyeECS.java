package com.example.bullseyefx;

public class Cart {
    private String date_created;
    private int totalItems;
    private int itemId;
    private int cardId;

    public Cart() {

    }
}