import java.util.ArrayList;
import java.util.LinkedList;

public class LibraryDictionary<Book>{
    private final int DEFAULT_CAPACITY = 2000;
    private LinkedList<Integer>[] keysByID = new LinkedList[DEFAULT_CAPACITY];
    private LinkedList<String>[] keysByTitle = new LinkedList[DEFAULT_CAPACITY];
    private LinkedList<String>[] keysByAuthor = new LinkedList[DEFAULT_CAPACITY];
    private LinkedList<Book>[] valuesByID = new LinkedList[DEFAULT_CAPACITY];
    private LinkedList<Book>[] valuesByTitle = new LinkedList[DEFAULT_CAPACITY];
    private LinkedList<Book>[] valuesByAuthor = new LinkedList[DEFAULT_CAPACITY];
    private int countInID;
    private int countInTitle;
    private int countInAuthor;
    private int collisionCounterInID;
    private int collisionCounterInTitle;
    private int collisionCounterInAuthor;

    public int getCountInID() {
        return countInID;
    }

    public int getCountInTitle() {
        return countInTitle;
    }

    public int getCountInAuthor() {
        return countInAuthor;
    }

    public int getCollisionCounterInID() {
        return collisionCounterInID;
    }

    public int getCollisionCounterInTitle() {
        return collisionCounterInTitle;
    }

    public int getCollisionCounterInAuthor() {
        return collisionCounterInAuthor;
    }

    public Book getByID(int key) {
        int index = key;
        if (keysByID[index] == null) {
            System.out.println("Item does not exist.");
            return null;
        }
        int i = 0;
        while (!(keysByID[index].get(i) == key)) {
           i++;
        }
        return valuesByID[index].get(i);
    }

    public void putByID(int key, Book val) {
        int index = key;
        if (valuesByID[index] != null) {
            valuesByID[index].addFirst(val);
            keysByID[index].addFirst(key);
            collisionCounterInID++;
        }
        else {
            valuesByID[index] = new LinkedList<>();
            valuesByID[index].add(0, val);
            keysByID[index] = new LinkedList<>();
            keysByID[index].add(0, key);
            countInID++;
        }
    }

    public Book getByTitle(String key) {
        int index = hash(key);
        if (keysByTitle[index] == null) {
            System.out.println("Title does not exist.");
            return null;
        }
        int i = 0;
        while (!(keysByTitle[index].get(i).equals(key))) {
            if (i > keysByTitle[index].size()) {
                System.out.println("Title does not exist");
                return null;
            }
            i++;
        }
        return valuesByTitle[index].get(i);
    }

    public void putByTitle(String key, Book val) {
        int index = hash(key);
        if (valuesByTitle[index] != null) {
            valuesByTitle[index].addFirst(val);
            keysByTitle[index].addFirst(key);
            collisionCounterInTitle++;

        }
        else {
            valuesByTitle[index] = new LinkedList<>();
            valuesByTitle[index].add(0, val);
            keysByTitle[index] = new LinkedList<>();
            keysByTitle[index].add(0, key);
            countInTitle++;
        }
    }

    public ArrayList<Book> getByAuthor(String key) {
        int index = hash(key);
        if (keysByAuthor[index] == null) {
            System.out.println("Author does not exist.");
            return null;
        }
        ArrayList<Book> bookList = new ArrayList<>();
        for (int i = 0; i < keysByAuthor[index].size(); i++) {
            if (keysByAuthor[index].get(i).equals(key)) {
                bookList.add(valuesByAuthor[index].get(i));
            }
        }
        return bookList;
    }

    public void putByAuthor(String key, Book val) {
        int index = hash(key);
        if (valuesByAuthor[index] != null) {
            valuesByAuthor[index].addFirst(val);
            keysByAuthor[index].addFirst(key);
            collisionCounterInAuthor++;
        }
        else {
            valuesByAuthor[index] = new LinkedList<>();
            valuesByAuthor[index].add(0, val);
            keysByAuthor[index] = new LinkedList<>();
            keysByAuthor[index].add(0, key);
            countInAuthor++;
        }
    }
    private int hash(String key) {
        int hashVal = 0;
        for (int i = 0; i < key.length(); i++) {
                hashVal += key.charAt(i);
        }
        return hashVal % DEFAULT_CAPACITY;
    }
}