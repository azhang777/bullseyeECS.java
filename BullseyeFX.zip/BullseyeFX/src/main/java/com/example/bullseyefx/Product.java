package com.example.bullseyefx;

public class Product extends Inventory {
    private String name;
    private String gender;
    private String size;
    private String itemColor;
    private int quantityAmount;
    private int idNumber;
    private float price;

    public Product() {
    }
}
