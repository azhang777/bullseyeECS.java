package com.example.bullseyefx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;



public class CartController {
    Cart cart = new Cart();
    User user = new User();
    boolean cartLoaded;
    double total = 0;
    BufferedReader bufferedReader = null;
    File loggedUser = new File("C:\\Users\\andyz\\IdeaProjects\\BullseyeFX\\src\\main\\java\\com\\example\\bullseyefx\\loggedUser.txt");
    File orderHistory = new File("C:\\Users\\andyz\\IdeaProjects\\BullseyeFX\\src\\main\\java\\com\\example\\bullseyefx\\orderHistory.txt");
    @FXML
    private ListView<String> cartListView;
    @FXML
    private ListView<Float> priceListView;

    @FXML
    private ListView<String> accountListView;
    @FXML
    private Button accountBttn;

    @FXML
    private Button checkoutBttn;

    @FXML
    private Button homeBttn;
    @FXML
    private Button discountPromotionBttn;
    @FXML
    private Button loadCartBttn;

    @FXML
    private TextField promotionField;
    @FXML
    private TextField totalField;
    private Stage stage;
    private Scene scene;
    String promotionCode = "discount10";

    @FXML
    void loadCartBttnClicked(ActionEvent event) {
        Customer loggedCustomer = new Customer();
        try {
            FileReader file = new FileReader(loggedUser);
            bufferedReader = new BufferedReader(file);

            String line = "";

            while ((line = bufferedReader.readLine()) != null) {
                String[] data = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
                loggedCustomer.setUserID(data[0]);
                loggedCustomer.setPassword(data[1]);
                loggedCustomer.setFirstName(data[2]);
                loggedCustomer.setLastName(data[3]);
                loggedCustomer.setAddress(data[4]);
                loggedCustomer.setZipCode(data[5]);
                loggedCustomer.setEmail(data[6]);
                loggedCustomer.setPhoneNum(data[7]);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (user.getIs_logged_in()) {
            accountListView.getItems().add("Username: " + loggedCustomer.getUserID());
            accountListView.getItems().add("Password: " + loggedCustomer.getPassword());
            accountListView.getItems().add("First Name: " + loggedCustomer.getFirstName());
            accountListView.getItems().add("Last Name: " + loggedCustomer.getLastName());
            accountListView.getItems().add("Address: " + loggedCustomer.getAddress());
            accountListView.getItems().add("ZipCode: " + loggedCustomer.getZipCode());
            accountListView.getItems().add("Email: " + loggedCustomer.getEmail());
            accountListView.getItems().add("Phone Number: " + loggedCustomer.getPhoneNum());
            for (int i = 0; i < Cart.getCartList().size(); i++) {
                cartListView.getItems().add(Cart.getCartList().get(i).getName() + " " + Cart.getCartList().get(i).getGender() + " " +
                        Cart.getCartList().get(i).getSize() + " " + Cart.getCartList().get(i).getItemColor());
                priceListView.getItems().add(Cart.getCartList().get(i).getPrice());
                total += Cart.getCartList().get(i).getPrice();
            }
        }
        totalField.setText("Price: $" + total);
        cartLoaded = true;
        loadCartBttn.setVisible(false);
        loadCartBttn.setDisable(true);
    }
    @FXML
    void discountPromotionBttntClicked(ActionEvent event) {
        System.out.println("Discount Button Clicked");
        if (promotionField.getText().equals(promotionCode)) {
            System.out.println("discounted");
            total = total * .9;
            totalField.setText("Price: $" + total);
        }
        else {
            System.out.println("error discount");
            promotionField.setPromptText("Error");
        }
    }
    @FXML
    void checkoutBttnClicked(ActionEvent event) {
        //if user is not logged in, do not let them check out, do not save order
        System.out.println("Checkout Button pressed");
        checkoutBttn.setText("Checkout Processed!");
        // checks if true or false
        if (user.getIs_logged_in() && cartLoaded){
            checkoutBttn.setText("Checkout Processed!");
            cartLoaded = false;
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            String datePurchased = dtf.format(now);
            loadCartBttn.setVisible(true);
            loadCartBttn.setDisable(false);
            cartListView.getItems().clear();
            priceListView.getItems().clear();
            accountListView.getItems().clear();
            try {
                FileWriter writer = new FileWriter(orderHistory, true);
                for (int i = 0; i < Cart.getCartList().size(); i++) {
                    writer.write(Cart.getCartList().get(i).getName() + " " + Cart.getCartList().get(i).getGender() + " " +
                            Cart.getCartList().get(i).getSize() + " " + Cart.getCartList().get(i).getItemColor() + "\n");
                }
                writer.write(" $" + total + " Date Purchased: " + datePurchased + "\n");
                writer.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        else if (!user.getIs_logged_in()) {
            checkoutBttn.setText("You are not logged in yet.");
        }
    }

    @FXML
    void switchToHome(ActionEvent event) throws IOException {
        System.out.println("Switch to Home Clicked");
        Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("hello-view.fxml"));
        this.stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(this.scene);
        this.stage.show();
    }
    @FXML
    public void switchToAccount(ActionEvent event) throws IOException {
        System.out.println("Switch to Account Clicked");
        Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("account-view.fxml"));
        this.stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(this.scene);
        this.stage.show();
    }

}
