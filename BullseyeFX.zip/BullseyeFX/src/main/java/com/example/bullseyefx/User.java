
package com.example.bullseyefx;

public class User {
    private String userId;
    private String password;
    public static boolean is_logged_in;

    public User() {
    }

    public void authenticate() {

    }

    public void create() {

    }

    public Boolean getIs_logged_in() {
        return is_logged_in;
    }

    public void setIs_logged_in(Boolean is_logged_in) {
        User.is_logged_in = is_logged_in;
        //Testing, not actual requirements
        int test = 5;
        if (test == 5){
            is_logged_in = true;
        }
        else {
            is_logged_in = false;
        }
    }


}
