package com.example.bullseyefx;

public class Order {
    private String orderID;
    private String orderDate;
    private String orderDescription;
    private int orderItems;
    private float totalPrice;

    public Order() {

    }
}
