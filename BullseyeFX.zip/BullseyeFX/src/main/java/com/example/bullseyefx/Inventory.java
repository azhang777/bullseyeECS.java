package com.example.bullseyefx;

public class Inventory {
    private int quantityAmount;

    public int getQuantity() {
        return quantityAmount;
    }
    public void increaseQuantity() {
        this.quantityAmount++;
    }
    public void decreaseQuantity() {
        if (this.quantityAmount > 0) {
            this.quantityAmount--;
        }
    }
}
