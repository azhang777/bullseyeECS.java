package com.example.bullseyefx;


public class Customer extends User {
    private String phoneNum;
    private String address;
    private String zipCode;
    private String email;
    private String userID;
    private String password;
    private boolean is_logged_in;

    public Customer() {

    }

}
