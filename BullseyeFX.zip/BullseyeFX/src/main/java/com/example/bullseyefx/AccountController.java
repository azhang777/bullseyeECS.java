package com.example.bullseyefx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;

import java.io.IOException;

public class AccountController {

    @FXML
    private Button cartBttn;

    @FXML
    private Button homeBttn;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button signUpBttn;
    private Stage stage;
    private Scene scene;

    @FXML
    void switchToHome(ActionEvent event) throws IOException {
        System.out.println("Switch to Home Clicked");
        Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("hello-view.fxml"));
        this.stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(this.scene);
        this.stage.show();
    }

    public void switchToCart(ActionEvent event) throws IOException {
        System.out.println("Switch to Cart Clicked");
        Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("cart-view.fxml"));
        this.stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(this.scene);
        this.stage.show();
    }

        public void switchToSignUp(ActionEvent event) throws IOException {
        System.out.println("Switch to SignUp Clicked");
        Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("create-view.fxml"));
        this.stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(this.scene);
        this.stage.show();
    }
}
