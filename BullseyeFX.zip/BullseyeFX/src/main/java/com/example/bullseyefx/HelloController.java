package com.example.bullseyefx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloController {
    private Stage stage;
    private Scene scene;
    @FXML
    private Button accountBttn;
    @FXML
    private Button cartBttn;
    @FXML
    private Button homeBttn;

    public Boolean is_logged_in;

    public HelloController() {
    }
    @FXML
    void accountButtonClick(ActionEvent event) {
    }

    @FXML
    void cartBttnClicked(ActionEvent event) {
    }

//    @FXML
//    void switchToHome(ActionEvent event) throws IOException {
//        System.out.println("Switch to Home Clicked");
//        Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("hello-view.fxml"));
//        this.stage = (Stage)((Node)event.getSource()).getScene().getWindow();
//        this.scene = new Scene(root);
//        this.stage.setScene(this.scene);
//        this.stage.show();
//    }

    @FXML
    public void switchToAccount(ActionEvent event) throws IOException {
        System.out.println("Switch to Account Clicked");
        Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("account-view.fxml"));
        this.stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(this.scene);
        this.stage.show();
        //accountController.logOutBttnClicked(event); cannot call another controller's methods i guess
    }

    public void switchToCart(ActionEvent event) throws IOException {
        System.out.println("Switch to Cart Clicked");
        Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("cart-view.fxml"));
        this.stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(this.scene);
        this.stage.show();
    }

//    public void switchToSignUp(ActionEvent event) throws IOException {
//        System.out.println("Switch to Cart Clicked");
//        Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("create-view.fxml"));
//        this.stage = (Stage)((Node)event.getSource()).getScene().getWindow();
//        this.scene = new Scene(root);
//        this.stage.setScene(this.scene);
//        this.stage.show();
//    }

    public void createUser(ActionEvent actionEvent) {
    }
}