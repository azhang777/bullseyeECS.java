package com.example.bullseyefx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.*;

public class CreateController {
    @FXML
    private TextField AddressField;

    @FXML
    private TextField EmailField;

    @FXML
    private TextField PhoneNumberField;

    @FXML
    private TextField ZipCodeField;

    @FXML
    private Button accountBttn;

    @FXML
    private Button createBttn;

    @FXML
    private TextField firstNameField;

    @FXML
    private TextField lastNameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField usernameField;
    private Scene scene;
    private Stage stage;

    @FXML
    void createUser(ActionEvent event) throws InterruptedException {
        //if any conditions are empty, anyIsEmpty will be false, if anyIsEmpty is false, cannot create account and write to csv.
        boolean anyIsEmpty;
        if (usernameField.getText().isEmpty()) {
            anyIsEmpty = true;
            usernameField.setPromptText("Error");
        } else if (passwordField.getText().isEmpty()) {
            anyIsEmpty = true;
            passwordField.setPromptText("Error");
        } else if (firstNameField.getText().isEmpty()) {
            anyIsEmpty = true;
            firstNameField.setPromptText("Error");
        } else if (lastNameField.getText().isEmpty()) {
            anyIsEmpty = true;
            lastNameField.setPromptText("Error");
        } else if (AddressField.getText().isEmpty()) {
            anyIsEmpty = true;
            AddressField.setPromptText("Error");
        } else if (ZipCodeField.getText().isEmpty()) {
            anyIsEmpty = true;
            ZipCodeField.setPromptText("Error");
        } else if (EmailField.getText().isEmpty()) {
            anyIsEmpty = true;
            EmailField.setPromptText("Error");
        } else if (PhoneNumberField.getText().isEmpty()) {
            anyIsEmpty = true;
            PhoneNumberField.setPromptText("Error");
        } else {
            anyIsEmpty = false;
        }

        if (anyIsEmpty) {
            createBttn.setText("Error");
        } else {
            createBttn.setText("Account Created.");
            System.out.println("Create Account Clicked");
            try {
                FileWriter file = new FileWriter("C:\\Users\\andyz\\IdeaProjects\\BullseyeFX\\src\\main\\java\\com\\example\\bullseyefx\\UserInfo.csv", true);
                BufferedWriter bufferedWriter = new BufferedWriter(file);

                bufferedWriter.write("\n");
                bufferedWriter.write(usernameField.getText() + ",");
                bufferedWriter.write(passwordField.getText() + ",");
                bufferedWriter.write(firstNameField.getText() + ",");
                bufferedWriter.write(lastNameField.getText() + ",");
                bufferedWriter.write(AddressField.getText() + ",");
                bufferedWriter.write(ZipCodeField.getText() + ",");
                bufferedWriter.write(EmailField.getText() + ",");
                bufferedWriter.write(PhoneNumberField.getText());
                bufferedWriter.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    void switchToAccount(ActionEvent event) throws IOException {
        System.out.println("Switch to Account Clicked");
        Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("account-view.fxml"));
        this.stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(this.scene);
        this.stage.show();
    }

}
