package com.example.bulleyefx;

public class Cart {
    private String date_created;
    private int totalItems, itemId, cardId;


    /*
       addCartItem()
    removeCartItem()
    viewCartDetails()
    checkOut()
    */

}