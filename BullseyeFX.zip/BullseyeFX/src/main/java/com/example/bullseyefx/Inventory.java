package com.example.bullseyefx;

public class Inventory {
    public Inventory() {
    }
}
