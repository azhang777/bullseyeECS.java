import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static<K> void main(String[] args) {
        boolean keepGoing = true;
        Scanner scanner = new Scanner(System.in);
        BufferedReader br;

        LibraryDictionary<Book> bookLibrary = new LibraryDictionary<>();
        try {
            ArrayList<Book> bookList = new ArrayList<>();
            //Reading the csv file
            br = new BufferedReader(new FileReader("ProjectTwo/src/books.csv"));
            String line = "";
            //Read to skip the header
            br.readLine();
            //Reading from the second line
            while ((line = br.readLine()) != null) {
                String[] bookDetails = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
                if (bookDetails.length > 0) {
                    Book book = new Book();
                    book.setNumberID(Integer.parseInt(bookDetails[0]));
                    book.setTitle_book(bookDetails[1].trim());
                    book.setTitle_series(bookDetails[2]);
                    book.setAuthor_name(bookDetails[3]);
                    book.setHas_series(Boolean.parseBoolean(bookDetails[4]));
                    book.setSeries_number(Integer.parseInt(bookDetails[5]));
                    book.setAvg_rating(Float.parseFloat(bookDetails[6]));
                    book.setTotal_rating(Integer.parseInt(bookDetails[7]));
                    book.setVoters(Integer.parseInt(bookDetails[8]));
                    book.setScore(Integer.parseInt(bookDetails[9]));
                    bookList.add(book);
                    //bookLibrary.put(book.getNumberID(),book.getTitle_book(),book.getAuthor_name(), book);
                    bookLibrary.putByID(book.getNumberID(), book);
                    bookLibrary.putByTitle(book.getTitle_book(), book);
                    bookLibrary.putByAuthor(book.getAuthor_name(), book);
//                    bookLibrary2.putByTitle(book.getTitle_book(), book);
//                    bookLibrary3.putByAuthor(book.getAuthor_name(), book);
                }
            } // end of the while loop
        }
        catch (Exception ee) {
            ee.printStackTrace();
        }
        System.out.println("Personal Book Database has loaded.\n" + "Count in ID:"  + bookLibrary.getCountInID() + ", Count in Title:" + bookLibrary.getCountInTitle() + ", Count in Author:" + bookLibrary.getCountInAuthor());
        System.out.println("Collisions in ID, Title, Author: " + bookLibrary.getCollisionCounterInID() + "," + bookLibrary.getCollisionCounterInTitle() + "," + bookLibrary.getCollisionCounterInAuthor());

        while (keepGoing) {
            System.out.println("1. Search by Number ID\n2. Search by Title\n3. Search by Author\n4. Quit\n");
            int userInput = scanner.nextInt();
            if (userInput == 1) {
                System.out.println("Please enter Number ID: ");
                int bookNumberID = scanner.nextInt();
                while (bookNumberID < 0 || bookNumberID > 2000) {
                    System.out.println("ID is out of bounds, please try.");
                    bookNumberID = scanner.nextInt();
                }
                System.out.println(bookLibrary.getByID(bookNumberID) + "\n");
            }
            else if (userInput == 2) {
                System.out.println("Please enter Title: ");
                scanner.nextLine();
                String bookTitleInput = scanner.nextLine();
                System.out.println(bookLibrary.getByTitle(bookTitleInput) + "\n");
            }
            else if (userInput == 3) {
                System.out.println("Please enter Author: ");
                scanner.nextLine();
                String authorNameInput = scanner.nextLine();
                System.out.println(bookLibrary.getByAuthor(authorNameInput) + "\n");
            }
            else if (userInput == 4) {
                keepGoing = false;
            }
            else {

            }
        }
        System.out.println("wow");
    }
}
