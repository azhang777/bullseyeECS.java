package com.example.bullseyefx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CartController {

    @FXML
    private ListView<String> accountListView;

    @FXML
    private ListView<Product> cartListView;
    @FXML
    private Button accountBttn;

    @FXML
    private Button checkoutBttn;

    @FXML
    private Button homeBttn;

    @FXML
    private TextField promotionField;
    @FXML
    private TextField totalField;
    private Stage stage;
    private Scene scene;
    static List<Product> cartList = new ArrayList<>();
    @FXML
    void checkoutBttnClicked(ActionEvent event) {
        //if user is not logged in, do not let them check out, do not save order
        for (Product product : cartList) {
            cartListView.getItems().add(product);
        }
        System.out.println("Checkout Button pressed");
        checkoutBttn.setText("Checkout Processed!");
        User user = new User();
        // checks if true or false
        if (user.getIs_logged_in()){
            checkoutBttn.setText("Checkout Processed!");
        }else if (!user.getIs_logged_in()){
            checkoutBttn.setText("You are not logged in yet.");

        }
    }

    void initialize() {
    }
    @FXML
    void switchToHome(ActionEvent event) throws IOException {
        System.out.println("Switch to Home Clicked");
        Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("hello-view.fxml"));
        this.stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(this.scene);
        this.stage.show();
    }
    @FXML
    public void switchToAccount(ActionEvent event) throws IOException {
        System.out.println("Switch to Account Clicked");
        Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("account-view.fxml"));
        this.stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(this.scene);
        this.stage.show();
    }

}
