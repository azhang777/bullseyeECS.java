module com.example.bulleyefx {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.example.bulleyefx to javafx.fxml;
    exports com.example.bulleyefx;
}