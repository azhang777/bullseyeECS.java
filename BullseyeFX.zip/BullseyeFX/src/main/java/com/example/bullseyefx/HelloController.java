package com.example.bullseyefx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;

public class HelloController {
    private Stage stage;
    private Scene scene;
    CartController cartController = new CartController();
    @FXML
    private Button accountBttn;
    @FXML
    private Button cartBttn;
    @FXML
    private Button homeBttn;

    public Boolean is_logged_in;
    @FXML
    private ImageView blueShirtIMG;
    BufferedReader bufferedReader = null;
    //List<Product> productsList = new ArrayList<>();
    static HashMap<Integer, Product> productHashMap = new HashMap<>();
    void initialize() {
        try {
            FileReader dataFile = new FileReader("C:\\Users\\andyz\\IdeaProjects\\BullseyeFX\\src\\main\\java\\com\\example\\bullseyefx\\ProductInventory.csv");
            bufferedReader = new BufferedReader(dataFile);

            String line = "";
            bufferedReader.readLine();
            while ((line = bufferedReader.readLine()) != null) {
                String[] data = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
                Product product = new Product();
                product.setName(data[0]);
                product.setGender(data[1]);
                product.setSize(data[2]);
                product.setItemColor(data[3]);
                product.setQuantityAmount(Integer.parseInt(data[4]));
                product.setIdNumber(Integer.parseInt(data[5]));
                product.setPrice(Float.parseFloat(data[6]));
                productHashMap.put(product.getIdNumber(), product);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    @FXML
    void accountButtonClick(ActionEvent event) {

    }
    @FXML
    void addToCartBlackShirt(ActionEvent event) {
        System.out.println(productHashMap.get(1000833));
        productHashMap.get(1000833).decreaseQuantity();
        CartController.cartList.add(productHashMap.get(1000833));
    }

    @FXML
    void addToCartBlackShort(ActionEvent event) {
        System.out.println(productHashMap.get(1000222));
        productHashMap.get(1000222).decreaseQuantity();
        CartController.cartList.add(productHashMap.get(1000222));
    }

    @FXML
    void addToCartBlueShirt(ActionEvent event) {
        System.out.println(productHashMap.get(1000213));
        productHashMap.get(1000213).decreaseQuantity();
        CartController.cartList.add(productHashMap.get(1000213));
    }

    @FXML
    void addToCartBlueShoe(ActionEvent event) {
        System.out.println(productHashMap.get(1000212));
        productHashMap.get(1000212).decreaseQuantity();
        CartController.cartList.add(productHashMap.get(1000212));
    }

    @FXML
    void addToCartBrownCoat(ActionEvent event) {
        System.out.println(productHashMap.get(1000113));
        productHashMap.get(1000113).decreaseQuantity();
        CartController.cartList.add(productHashMap.get(1000113));
    }

    @FXML
    void addToCartBrownShort(ActionEvent event) {
        System.out.println(productHashMap.get(1000674));
        productHashMap.get(1000674).decreaseQuantity();
        CartController.cartList.add(productHashMap.get(1000674));
    }

    @FXML
    void addToCartGreyShort(ActionEvent event) {
        System.out.println(productHashMap.get(1000993));
        productHashMap.get(1000993).decreaseQuantity();
        CartController.cartList.add(productHashMap.get(1000993));
    }

    @FXML
    void addToCartNavyCoat(ActionEvent event) {
        System.out.println(productHashMap.get(1000312));
        productHashMap.get(1000312).decreaseQuantity();
        CartController.cartList.add(productHashMap.get(1000312));
    }

    @FXML
    void addToCartRedShirt(ActionEvent event) {
        System.out.println(productHashMap.get(1000231));
        productHashMap.get(1000231).decreaseQuantity();
        CartController.cartList.add(productHashMap.get(1000231));
    }

    @FXML
    void addToCartRedShoe(ActionEvent event) {
        System.out.println(productHashMap.get(1000489));
        productHashMap.get(1000489).decreaseQuantity();
        CartController.cartList.add(productHashMap.get(1000489));
    }

    @FXML
    void addToCartTanCoat(ActionEvent event) {
        System.out.println(productHashMap.get(1000852));
        productHashMap.get(1000852).decreaseQuantity();
        CartController.cartList.add(productHashMap.get(1000852));
    }

    @FXML
    void addtoCartBlackShoe(ActionEvent event) {
        System.out.println(productHashMap.get(1000324));
        productHashMap.get(1000324).decreaseQuantity();
        CartController.cartList.add(productHashMap.get(1000324));
    }
    @FXML
    public void switchToAccount(ActionEvent event) throws IOException {
        System.out.println("Switch to Account Clicked");
        Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("account-view.fxml"));
        this.stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(this.scene);
        this.stage.show();
        //accountController.logOutBttnClicked(event); cannot call another controller's methods i guess
    }
    public void switchToCart(ActionEvent event) throws IOException {
        System.out.println("Switch to Cart Clicked");
        Parent root = (Parent)FXMLLoader.load(this.getClass().getResource("cart-view.fxml"));
        this.stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        this.scene = new Scene(root);
        this.stage.setScene(this.scene);
        this.stage.show();
    }
    @FXML
    void addToCart(MouseEvent actionEvent) {
        System.out.println("Added to cart");
        try {
            FileWriter file = new FileWriter("C:\\Users\\andyz\\IdeaProjects\\BullseyeFX\\src\\main\\java\\com\\example\\bullseyefx\\cart.csv", true);
            BufferedWriter bufferedWriter = new BufferedWriter(file);
            Product product = new Product();
            bufferedWriter.write("\n");



            bufferedWriter.close();
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}